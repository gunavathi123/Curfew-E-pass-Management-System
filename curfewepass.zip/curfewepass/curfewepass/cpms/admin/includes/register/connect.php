<?php
	$Name = $_POST['Name'];
	$email = $_POST['email'];
	$number = $_POST['number'];
	$location = $_POST['location'];
	$destination = $_POST['destination'];

	// Database connection
	$conn = new mysqli('localhost','root','','mydb2');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into register(Name,email,number,identitycard,identitynumber,location,destination,fromdate,todate,reason) values(?, ?, ?, ?, ?,?,?,?,?
?)");
		$stmt->bind_param("ssisiss",$Name,$email,$number,$identitycard,$identitynumber,$location,$destination);
		$execval = $stmt->execute();
		echo $execval;
		echo "Registered successfully...";
		$stmt->close();
		$conn->close();
	}
?>