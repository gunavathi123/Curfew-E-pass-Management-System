<!DOCTYPE html>
<html>

<head>
   
    <title>Curfew Pass Management System |Users</title>
    <!-- Core CSS - Include with every page -->
    <link href="assets/plugins/bootstrap/bootstrap.css" rel="stylesheet" />
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/plugins/pace/pace-theme-big-counter.css" rel="stylesheet" />
  <link href="assets/css/style.css" rel="stylesheet" />
      <link href="assets/css/main-style.css" rel="stylesheet" />

    <!-- Page-Level CSS -->
    <link href="assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />

</head>

<body>
    <!--  wrapper -->
    <div id="wrapper">
        <!-- navbar top -->
       <?php include_once('includes/header.php');?>
        <!-- end navbar top -->

        <!-- navbar side -->
        <?php include_once('includes/sidebar.php');?>
        <!-- end navbar side -->
        <!--  page-wrapper -->
        <div id="page-wrapper">

            
            <div class="row">
                 <!--  page header -->
                <div class="col-lg-12">
                    <h1 class="page-header">Users</h1>
                </div>
                 <!-- end  page header -->
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                      
                        <div class="panel-body">
                            <div class="table-responsive">
					<form action=""method="POST">
						
					</form>	
					
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                       
                                           <th>Name</th>
                                            <th>Email</th>
                                            <th>Number</th>
							  <th>Identitycard</th>
							  <th>IdentityNumber</th>	
                                            <th>Location</th>
                                            <th>Destination</th>
							  <th>Fromdate</th>
							  <th>Todate</th>	
							 <th>reason</th>
                                      
                                        </tr>
                                    </thead>
                                    <tbody>
<?php
$connection=mysqli_connect("localhost","root","");
$db=mysqli_select_db($connection,'mydb3');
$query_run=mysqli_query($connection,"select * from register");
while($row=mysqli_fetch_array($query_run))
{
?>
<tr>
<td><?php echo $row['Name'];?></td>
<td><?php echo $row['email'];?></td>
<td><?php echo $row['number'];?></td>
<td><?php echo $row['itype'];?></td>
<td><?php echo $row['idnum'];?></td>
<td><?php echo $row['location'];?></td>
<td><?php echo $row['destination'];?></td>
<td><?php echo $row['fromdate'];?></td>
<td><?php echo $row['todate'];?></td>
<td><?php echo $row['reason'];?></td>

</tr>
<?php
}
?>


    <!-- Core Scripts - Include with every page -->
    <script src="assets/plugins/jquery-1.10.2.js"></script>
    <script src="assets/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="assets/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="assets/plugins/pace/pace.js"></script>
    <script src="assets/scripts/siminta.js"></script>
    <!-- Page-Level Plugin Scripts-->
 

</body>

</html>
