<?php
session_start();
//error_reporting(0);
include('includes/dbconnection.php');

  ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CurfewPass</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style4.css">    
</head>
<body>
    <header>
    <div class="wrapper">
        <div class="logo">
            <img src="logo.jpeg" alt="">
        </div>
<ul class="nav-area">
<li><a href="#">Home</a></li>
<li><a href="admin">Admin</a></li>
<li><a href="search.php">Search Pass</a></li>
<li><a href="userlogin">Uesr</a></li>
</ul>
</div>
<div class="welcome-text">
        <h1>
<span>CURFEW E-PASS MANAGEMENT SYSTEM</span></h2>

    </div>
</header>

</body>

  <!-- ================ start footer Area ================= -->
   <?php include_once('includes/footer.php');?>
  <!-- ================ End footer Area ================= -->




  <script src="vendors/jquery/jquery-3.2.1.min.js"></script>
  <script src="vendors/bootstrap/bootstrap.bundle.min.js"></script>
  <script src="vendors/owl-carousel/owl.carousel.min.js"></script>
  <script src="js/jquery.ajaxchimp.min.js"></script>
  <script src="js/mail-script.js"></script>
  <script src="js/main.js"></script>
</body>
</html>