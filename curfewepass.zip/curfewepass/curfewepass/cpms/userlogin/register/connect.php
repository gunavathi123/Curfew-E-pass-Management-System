<?php
	$Name = $_POST['Name'];
	$email = $_POST['email'];
	$number = $_POST['number'];
	$itype = $_POST['itype'];
	$idnum = $_POST['idnum'];
	$location = $_POST['location'];
	$destination = $_POST['destination'];
	$fromdate = $_POST['fromdate'];
	$todate = $_POST['todate'];
	$reason = $_POST['reason'];

	// Database connection
	$conn = new mysqli('localhost','root','','mydb3');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
	$stmt = $conn->prepare("insert into register(Name,email,number,itype,idnum,location,destination,fromdate,todate,reason) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
		$stmt->bind_param("ssisisssss",$Name,$email,$number,$itype,$idnum,$location,$destination,$fromdate,$todate,$reason);
		$execval = $stmt->execute();
		echo $execval;
		echo "Registered successfully...";
		$stmt->close();
		$conn->close();
	}
?>